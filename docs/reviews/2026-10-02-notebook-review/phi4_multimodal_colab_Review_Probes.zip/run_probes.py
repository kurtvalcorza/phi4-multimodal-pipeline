"""Probes for the Notebook Review Framework v1 review of tutorials/phi4_multimodal_colab.ipynb (row 61).

CPU-only. No model weights are loaded. Run from the repository root:
    CUDA_VISIBLE_DEVICES=-1 python run_probes.py [--evidence <kaggle v5 evidence dir>] [--out results.json]
Writes results.json and source_manifest.json next to this script (or --out).
Probe evidence bases: P1/P2/P5/P6 source inspection (AST over the committed notebook); P3/P4 direct execution of
the carried samples.py helpers with synthetic JPEG stand-ins (no model); P7/P8 documented execution evidence (the
hosted Kaggle T4 record of the exact blob 75ab9bb4); P9 direct execution of the repository's own static checks.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import io
import json
import os
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path.cwd()
NB = ROOT / "tutorials" / "phi4_multimodal_colab.ipynb"
results: dict = {}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git_blob(path: Path) -> str:
    data = path.read_bytes()
    return hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()


def cells():
    nb = json.loads(NB.read_text(encoding="utf-8"))
    return nb, [("".join(c["source"]), c["cell_type"]) for c in nb["cells"]]


def p1_parse():
    nb, cs = cells()
    code = [i for i, (_, t) in enumerate(cs) if t == "code"]
    compiled = []
    for i in code:
        compile(cs[i][0], f"cell{i}", "exec")
        compiled.append(i)
    results["P1_parse"] = {
        "blob": git_blob(NB), "cells": len(cs), "code_cells": len(code), "compiled": len(compiled),
        "metadata_dimer": nb["metadata"]["dimer"], "outputs_persisted": sum(len(c.get("outputs", [])) for c in nb["cells"]),
        "largest_code_cells_bytes": sorted(((len(cs[i][0]), i) for i in code), reverse=True)[:3],
    }


def names_used(src: str, name: str) -> list[int]:
    tree = ast.parse(src)
    return sorted({n.lineno for n in ast.walk(tree) if isinstance(n, ast.Name) and n.id == name})


def p2_rerun_state():
    _, cs = cells()
    out = {}
    for i, (src, t) in enumerate(cs):
        if t != "code":
            continue
        tree = ast.parse(src)
        assigns = [n.lineno for n in ast.walk(tree) if isinstance(n, ast.Name) and n.id == "pipe" and isinstance(n.ctx, ast.Store)]
        deletes = [n.lineno for n in ast.walk(tree) if isinstance(n, ast.Name) and n.id == "pipe" and isinstance(n.ctx, ast.Del)]
        loads = [n.lineno for n in ast.walk(tree) if isinstance(n, ast.Name) and n.id == "pipe" and isinstance(n.ctx, ast.Load)]
        if assigns or deletes or loads:
            out[f"cell{i}"] = {"assign": assigns, "del": deletes, "load_count": len(loads)}
    # Simulate the documented BYOD rerun ("re-run from that cell", Section 4) after Section 9 completed.
    ns: dict = {"pipe": object()}
    exec("del pipe", ns)
    try:
        exec("pipe.device", ns)
        sim = "no error"
    except NameError as exc:
        sim = f"NameError: {exc}"
    pipeline_src = (ROOT / "src/phi4_multimodal_pipeline/pipeline.py").read_text(encoding="utf-8")
    out["simulated_rerun_after_section9"] = sim
    out["adapt_frozen_state_is_current_tensors"] = "frozen_state = {n: p.detach().clone() for n, p in params_by_name.items()}" in pipeline_src
    out["adapt_resets_to_checkpoint_lora"] = "reset" in pipeline_src.split("def adapt(", 1)[1].split("def save_artifact", 1)[0].lower()
    results["P2_rerun_state"] = out


def make_jpeg(path: Path, k: int) -> None:
    from PIL import Image
    Image.new("RGB", (64, 48), ((k * 37) % 256, (k * 91) % 256, (k * 13) % 256)).save(path, "JPEG")


def p3_byod_minimum():
    sys.path.insert(0, str(ROOT / "src"))
    from phi4_multimodal_pipeline.samples import check_split_disjoint, split_dataset, validate_dataset
    out = {}
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        for n in (8, 12, 20, 30, 40, 49, 50, 53, 54, 60):
            d = base / f"n{n}"
            d.mkdir()
            records = []
            for k in range(n):
                make_jpeg(d / f"p{k}.jpg", k)
                records.append({"id": f"r{k}", "image": f"p{k}.jpg", "captions": [f"a photograph number {k}"]})
            sizes = None
            try:
                splits = split_dataset(records, seed=42, base_dir=d)  # cell 13, BYOD branch
                sizes = {k: len(v) for k, v in splits.items()}
                manifests = {name: validate_dataset(part) for name, part in splits.items()}  # cell 13, every split
                check_split_disjoint({k: m["records"] for k, m in manifests.items()})
                out[n] = {"split_sizes": sizes, "verdict": "accepted"}
            except ValueError as exc:
                out[n] = {"split_sizes": sizes, "verdict": "rejected", "message": str(exc)}
    results["P3_byod_minimum"] = out


def cell13_extract(payload: bytes, byod_dir: Path):
    """Verbatim extraction logic of cell 13 (after files.upload())."""
    byod_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        for member in archive.infolist():
            name = Path(member.filename).name
            if member.is_dir() or not name or name.startswith("."):
                continue
            (byod_dir / name).write_bytes(archive.read(member))
    return next(p for p in (byod_dir / "records.jsonl", byod_dir / "records.json") if p.is_file())


def p4_byod_zip():
    out = {}
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        img = base / "a.jpg"
        make_jpeg(img, 1)
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            z.write(img, "photos/a.jpg")
            z.writestr("captions.jsonl", '{"id":"a","image":"a.jpg","captions":["x"]}\n')
        try:
            cell13_extract(buf.getvalue(), base / "w1")
            out["missing_records_jsonl"] = "accepted"
        except StopIteration:
            out["missing_records_jsonl"] = "StopIteration (bare, no message)"
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            z.write(img, "photos/a.jpg")
            z.write(img, "other/a.jpg")
            z.writestr("records.jsonl", "")
        cell13_extract(buf.getvalue(), base / "w2")
        out["same_basename_in_two_folders"] = sorted(p.name for p in (base / "w2").iterdir())
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            z.writestr("../../evil.txt", "x")
            z.writestr("records.jsonl", "")
        cell13_extract(buf.getvalue(), base / "w3")
        out["traversal_entry_written_inside_root"] = (base / "w3" / "evil.txt").is_file() and not (base / "evil.txt").exists()
    results["P4_byod_zip"] = out


def p5_colab_only():
    _, cs = cells()
    src = cs[13][0]
    try:
        import google.colab  # noqa: F401
        here = "importable"
    except ModuleNotFoundError as exc:
        here = f"ModuleNotFoundError: {exc}"
    results["P5_colab_only_upload"] = {
        "cell13_imports_google_colab": "from google.colab import files" in src,
        "location_field_present": "BYOD_PATH" in src or "BYOD_ZIP" in src,
        "import_outside_colab": here,
        "prereq_names_kaggle_as_supported": "Google Colab or Kaggle" in cs[1][0],
    }


def p6_assertions():
    _, cs = cells()
    out = []
    for i, (src, t) in enumerate(cs):
        if t != "code":
            continue
        for node in ast.walk(ast.parse(src)):
            if isinstance(node, ast.Assert):
                out.append({"cell": i, "test": ast.unparse(node.test), "has_message": node.msg is not None})
    results["P6_outcome_assertions"] = out


def p7_prose_vs_record(evidence: Path | None):
    _, cs = cells()
    quotes = {
        "cell16_expect_close": "its CIDEr-D sits close to the baselines" in cs[16][0],
        "cell24_close_to_constant": "CIDEr-D scores that style close to a caption that never looks at the image" in cs[24][0],
        "cell24_caption_for_caption": "the adapter reloads caption for caption" in cs[24][0],
        "cell24_400M": "400 M parameters" in cs[24][0],
        "cell0_45_minutes": "about 45 minutes" in cs[0][0],
        "cell22_more_literal": "shorter, more literal captions" in cs[22][0],
        "readme_inference_only": "Adaptation in this repository: none; inference only" in (ROOT / "README.md").read_text(encoding="utf-8"),
        "trained_layers_32_params": 92274688 * 4,
    }
    rec = {}
    if evidence and (evidence / "executed.ipynb").is_file():
        res = json.loads((evidence / "outputs" / "phi4_multimodal_result.json").read_text(encoding="utf-8"))
        cmp = res["comparison"]
        rec = {
            "cider_d": cmp["cider_d"], "mean_words": cmp["mean_words"],
            "frozen_over_best_baseline_cider_ratio": round(cmp["cider_d"]["frozen"] / max(cmp["cider_d"]["constant_caption"], cmp["cider_d"]["colour_neighbour"]), 1),
            "reload_parity": res["reload_parity"],
            "examples": res["examples"],
        }
        summ = json.loads((evidence / "run_summary.json").read_text(encoding="utf-8"))
        rec["passes"] = [{"attempt": p.get("attempt"), "ok": p.get("ok"), "error_tail": (p.get("error") or "")[-260:]} for p in summ["runner"]["passes"]]
        rec["candidate_sha"] = summ["identity"]["candidate_sha"]
        rec["committed_blob"] = summ["identity"]["committed_blob"]
    results["P7_prose_vs_hosted_record"] = {"quotes_present": quotes, "hosted_record": rec}


def p9_static_checks():
    out = {}
    env = dict(os.environ, CUDA_VISIBLE_DEVICES="-1", PYTHONPATH="src")
    for label, cmd in {
        "pytest": [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider"],
        "validate_release_assets": [sys.executable, "tools/validate_release_assets.py"],
        "build_notebook_check": [sys.executable, "tools/build_notebook.py", "--check"],
    }.items():
        proc = subprocess.run(cmd, capture_output=True, text=True, env=env, timeout=600)
        tail = (proc.stdout + proc.stderr).strip().splitlines()
        out[label] = {"exit": proc.returncode, "tail": tail[-2:],
                      "tests_passed_dots": (proc.stdout.split("\n")[0].count(".") if label == "pytest" else None)}
    results["P9_repo_static_checks"] = out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--evidence", type=Path, default=None)
    ap.add_argument("--out", type=Path, default=Path(__file__).with_name("results.json"))
    a = ap.parse_args()
    for probe in (p1_parse, p2_rerun_state, p3_byod_minimum, p4_byod_zip, p5_colab_only, p6_assertions):
        probe()
    p7_prose_vs_record(a.evidence)
    p9_static_checks()
    a.out.write_text(json.dumps(results, indent=1, ensure_ascii=False, default=str), encoding="utf-8")
    files = ["tutorials/phi4_multimodal_colab.ipynb", "tutorials/README.md", "README.md", "STATUS.md", "MODEL_CARD.md",
             "docs/release-verification.md", "docs/WEIGHTS.md", "src/phi4_multimodal_pipeline/pipeline.py",
             "src/phi4_multimodal_pipeline/metrics.py", "src/phi4_multimodal_pipeline/samples.py",
             "tools/build_notebook.py", "tools/notebook_template.py", "tools/validate_release_assets.py", "pyproject.toml"]
    manifest = {f: sha256(ROOT / f) for f in files}
    if a.evidence:
        for f in ("run_summary.json", "executed.ipynb", "executed-pass1.ipynb", "outputs/phi4_multimodal_result.json"):
            manifest["kaggle-v5-evidence/" + f] = sha256(a.evidence / f)
    a.out.with_name("source_manifest.json").write_text(json.dumps(manifest, indent=1), encoding="utf-8")


if __name__ == "__main__":
    main()
